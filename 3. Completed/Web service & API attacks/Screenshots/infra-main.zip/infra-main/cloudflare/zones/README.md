# Zones

In the root folder, you will find the zone definition itself. Then, a folder includes resources such as records, page rules, and firewall rules for each zone. Each resource has its own state and its module. The structure looks like that:

```
├── cloudflare
│   └── zones
│       ├── main.tf
│       ├── variables.tf
│       ├── backend.tf
│       ├── eltc.tech
│       │   ├── page_rules
│       │   │   ├── backend.tf
│       │   │   ├── main.tf
│       │   │   └── variables.tf
│       │   └── records
│       │   │   ├── backend.tf
│       │   │   ├── main.tf
│       │   │   └── variables.tf
│       │   └── firewall_rules
│       │       ├── backend.tf
│       │       ├── main.tf
│       │       └── variables.tf
│       ├── moonpay.com
│       │   ├── firewall_rules
│       │   │   ├── backend.tf
│       │   │   ├── main.tf
│       │   │   └── variables.tf
│       │   ├── page_rules
│       │   │   ├── backend.tf
│       │   │   ├── main.tf
│       │   │   └── variables.tf
│       │   └── records
│       │       ├── backend.tf
│       │       ├── main.tf
│       │       ├── records_A.tf
│       │       ├── records_CNAME.tf
│       │       ├── records_MX.tf
│       │       ├── records_NS.tf
│       │       └── records_TXT.tf
```

## Add new zone

The zones definition can be found in `cloudflare/zones/variables.tf`. To define the zone, you can use the following variables:

| Variable   | Description                                                                                                                                                                                                                                                |
| ---------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| zone_name  | The DNS zone name which will be added.                                                                                                                                                                                                                     |
| paused     | Boolean of whether this zone is paused                                                                                                                                                                                                                     |
| jump_start | Boolean of whether to scan for DNS records on creation                                                                                                                                                                                                     |
| plan       | The name of the commercial plan to apply to the zone, can be updated once the zone is created; one of free, pro, business, enterprise, partners_free, partners_pro, partners_business, partners_enterprise, partners_workers_ss, image_resizing_enterprise |
| type       | A full zone implies that DNS is hosted with Cloudflare. A partial zone is typically a partner-hosted zone or a CNAME setup. Valid values: full, partial                                                                                                    |

To add a new zone, create a new pull request adding a configuration block to the `variables.tf` file. Example:

```
variable "zones" {
  default = {
    moonassets-io = {
      zone_name  = "moonassets.io"
      paused     = false
      jump_start = false
      plan       = "free"
      type       = "full"
    },
    example-zone = {
      zone_name  = "example.zone"
      paused     = false
      jump_start = false
      plan       = "pro"
      type       = "full"
    },
  }
}
```

## Adding a new record

Records definition can be found in `cloudflare/zones/ZONE_NAME/records/variables.tf`. For large zone, variables files are split by record type. For example, if you need it to add a CNAME record to `moonpay.com`, you should add your record definition in `cloudflare/zones/ZONE_NAME/records/records_CNAME.tf`.

This module supports all records type. Each record type has its definition, requiring a different set of variables to provision each record. Records definition can be logical abstracted into two categories:

- Key-Value: Records are defined via a key-value mapping (A, AAAA, CNAME, TXT, NS, MX, etc.). A record example: moonpay.com 36.54.23.124.
- Key-Metadata: Records are defined via key-metadata mapping, where metadata will vary depending the record type (SRV, LOC, CERT, etc. ). SRV record example: (name: "test.test", service: "\_sip", proto: "\_tcp", port: "8080").

The majority of the records will fall into the first category, at least the most used ones. These records will always follow the exact variable definition:

| Variables | Description                                            |
| --------- | ------------------------------------------------------ |
| name      | The name of the record                                 |
| value     | The (string) value of the record.                      |
| type      | The type of the record                                 |
| ttl       | The TTL of the record (automatic: '1')                 |
| proxied   | Whether the record gets Cloudflare's origin protection |
| priority  | The priority of the record (MX records)                |

For the second group, each record type will have a different record definition. For more details about how to provision each one of the records type, you should refer to Cloudflare API documentation (https://api.cloudflare.com/#dns-records-for-a-zone-properties)

To add a new record, create a new pull request adding a configuration block to the `cloudflare/zones/ZONE_NAME/records/variables.tf` file. Resource identifiers are uniques. Example:

**A Record**

```
variable "records_A" {
  default = {
    mobilecoin-mainnet-moonpay-com = {
      name    = "mobilecoin-mainnet"
      value   = "34.120.83.83"
      type    = "A"
      ttl     = 1
      proxied = false
    },
    test-test-net = {
      name    = "test-test-net"
      value   = "34.111.169.75"
      type    = "A"
      ttl     = 1
      proxied = false
    }
  }
}
```

**CNAME Record**

```
variable "records_CNAME" {
  default = {
    access-moonpay-com = {
      name    = "access"
      value   = "moonpay.gpcloudservice.com"
      type    = "CNAME"
      ttl     = 1
      proxied = false
    },
    test-test-com = {
      name    = "test"
      value   = "test.gpcloudservice.com"
      type    = "CNAME"
      ttl     = 1
      proxied = false
    },
  }
}
```

**MX Record**

```
variable "records_MX" {
  default = {
    gh-mail-moonpay-com-MX-10-mxb = {
      name     = "gh-mail"
      value    = "mxb.mailgun.org"
      type     = "MX"
      ttl      = 1
      proxied  = false
      priority = 10
    },
    test-mx = {
      name     = "test-mx"
      value    = "mxb.mailgun.org"
      type     = "MX"
      ttl      = 1
      proxied  = false
      priority = 10
    },
  }
}
```

**TXT records**

```
variable "records_TXT" {
  default = {
    _amazonses-moonpay-com = {
      name    = "_amazonses"
      value   = "VKNH3BmA55Va+sZz4b1Y/vv01vnO+BIxpw+dEgF3EpA="
      type    = "TXT"
      ttl     = 1
      proxied = false
    },
    _test_txt_record = {
      name    = "_test_txt"
      value   = "KJHkggiujknndkuyKDFsdlkhvE=="
      type    = "TXT"
      ttl     = 1
      proxied = false
    },
  }
}
```

**SRV Record**

```
variable "records_SRV" {
  default = {
    _amazonses-moonpay-com = {
      name     = "_amazonses"
      type     = "SRV"
      ttl      = 1
      proxied  = false
      service  = "_sip"
      proto    = "_tcp"
      weight   = 5
      priority = 10
      port     = 8080
      target   = "example.com"
    },
    _example-moonpay-com = {
      name     = "_example"
      type     = "SRV"
      ttl      = 1
      proxied  = false
      service  = "_sip"
      proto    = "_tcp"
      weight   = 5
      priority = 10
      port     = 8080
      target   = "example.com"
    }
  }
}
```

## Adding a new page rule

Page rules definition can be found in `cloudflare/zones/ZONE_NAME/page_rules/variables.tf`. Resource identifiers are uniques. To define a new page rule, you can use the following variables:

**Required**

| Variable   | Description                                                                                                                                                                                                                                                |
| ---------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| zone_name  | The DNS zone name which will be added.                                                                                                                                                                                                                     |
| paused     | Boolean of whether this zone is paused                                                                                                                                                                                                                     |
| jump_start | Boolean of whether to scan for DNS records on creation                                                                                                                                                                                                     |
| plan       | The name of the commercial plan to apply to the zone, can be updated once the zone is created; one of free, pro, business, enterprise, partners_free, partners_pro, partners_business, partners_enterprise, partners_workers_ss, image_resizing_enterprise |
| type       | A full zone implies that DNS is hosted with Cloudflare. A partial zone is typically a partner-hosted zone or a CNAME setup. Valid values: full, partial                                                                                                    |

**Optional (one at least required)**

| Variables                   | Description                                                                                                                             |
| --------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- |
| always_use_https            | Boolean of whether this action is enabled. Default: false.                                                                              |
| automatic_https_rewrites    | Whether this action is "on" or "off".                                                                                                   |
| browser_cache_ttl           | The Time To Live for the browser cache. 0 means 'Respect Existing Headers'                                                              |
| browser_check               | Whether this action is "on" or "off".                                                                                                   |
| bypass_cache_on_cookie      | String value of cookie name to conditionally bypass cache the page.                                                                     |
| cache_by_device_type        | Whether this action is "on" or "off".                                                                                                   |
| cache_deception_armor       | Whether this action is "on" or "off".                                                                                                   |
| cache_key_fields            | Controls how Cloudflare creates Cache Keys used to identify files in cache. See below for full description.                             |
| cache_level                 | Whether to set the cache level to "bypass", "basic", "simplified", "aggressive", or "cache_everything".                                 |
| cache_on_cookie             | String value of cookie name to conditionally cache the page.                                                                            |
| cache_ttl_by_status         | Set cache TTL based on the response status from the origin web server. Can be specified multiple times. See below for full description. |
| disable_apps                | Boolean of whether this action is enabled. Default: false.                                                                              |
| disable_performance         | Boolean of whether this action is enabled. Default: false.                                                                              |
| disable_railgun             | Boolean of whether this action is enabled. Default: false.                                                                              |
| disable_security            | Boolean of whether this action is enabled. Default: false.                                                                              |
| disable_zaraz               | Boolean of whether this action is enabled. Default: false.                                                                              |
| edge_cache_ttl              | The Time To Live for the edge cache.                                                                                                    |
| email_obfuscation           | Whether this action is "on" or "off".                                                                                                   |
| explicit_cache_control      | Whether origin Cache-Control action is "on" or "off".                                                                                   |
| forwarding_url              | The URL to forward to, and with what status. See below.                                                                                 |
| host_header_override        | Value of the Host header to send.                                                                                                       |
| ip_geolocation              | Whether this action is "on" or "off".                                                                                                   |
| minify                      | The configuration for HTML, CSS and JS minification. See below for full list of options.                                                |
| mirage                      | Whether this action is "on" or "off".                                                                                                   |
| opportunistic_encryption    | Whether this action is "on" or "off".                                                                                                   |
| origin_error_page_pass_thru | Whether this action is "on" or "off".                                                                                                   |
| polish                      | Whether this action is "off", "lossless" or "lossy".                                                                                    |
| resolve_override            | Overridden origin server name.                                                                                                          |
| respect_strong_etag         | Whether this action is "on" or "off".                                                                                                   |
| response_buffering          | Whether this action is "on" or "off".                                                                                                   |
| rocket_loader               | Whether to set the rocket loader to "on", "off".                                                                                        |
| security_level              | Whether to set the security level to "off", "essentially_off", "low", "medium", "high", or "under_attack".                              |
| server_side_exclude         | Whether this action is "on" or "off".                                                                                                   |
| smart_errors                | Whether this action is "on" or "off".                                                                                                   |
| sort_query_string_for_cache | Whether this action is "on" or "off".                                                                                                   |
| ssl                         | Whether to set the SSL mode to "off", "flexible", "full", "strict", or "origin_pull".                                                   |
| true_client_ip_header       | Whether this action is "on" or "off".                                                                                                   |
| waf                         | Whether this action is "on" or "off".                                                                                                   |

To add a new page rule, create a new pull request adding a configuration block to the `cloudflare/zones/ZONE_NAME/page_rules/variables.tf` file. Resource identifiers are uniques Example:

```
variable "page_rules" {
  default = {
    a51d7e7a4d9bca73945b5e19f1a4c87f1 = {
      target           = "http://eltwallet.eltcoin.tech/*"
      priority         = "2"
      always_use_https = true
    },
    example_test_rule = {
      target      = "*example.test/test.js"
      priority    = "1"
      cache_level = "bypass"
    }
  }
}
```

For more information about the resource, we recommend having a look at the current Cloudflare API documentation (https://api.cloudflare.com/#page-rules-for-a-zone-list-page-rules)

## Adding a firewall rule

Firewall rules definition can be found in `cloudflare/zones/ZONE_NAME/firewall_rules/variables.tf`. To define a new firewall rule, you can use the following variables:

| Variables  | Description                                                                                                                                                                |
| ---------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| action     | The action to apply to a matched request. Allowed values: "block", "challenge", "allow", "js_challenge", "managed_challenge", "bypass". Enterprise plan also allows "log". |
| expression | The filter expression to be used.                                                                                                                                          |

To add a new firewall rule, create a new pull request adding a configuration block to the `cloudflare/zones/ZONE_NAME/firewall_rules/variables.tf` file. Resource identifiers are uniques. Example:

```
variable "firewall_rules" {
  default = {
    assetnote-ip-whitelist = {
      rule_description = "Assetnote IP whitelist"
      expression       = "(ip.src in $assetnote_ips)"
      action           = "allow"
    },
    test-firewall-rule = {
      rule_description = "This is a firewall rule test"
      expression       = "(ip.src in $ip_blocklist_sec)"
      action           = "block"
    },
    test-firewall-rule-2 = {
      rule_description = "This is a firewall rule test 2"
      expression       = "(ip.src ne 192.0.2.1)"
      action           = "allow"
    },
  }
}
```

For more information on how to create expression, please refer to Cloudflare documentation (https://developers.cloudflare.com/ruleset-engine/rules-language/expressions/)
