# Account level resources

Account level resources can be found in ths folder. Currently we only support IP lists resources.

The folder structure looks like that:

```
├── cloudflare
│   ├── account
│   │   └── ip_list
│   │       ├── assetnote_ips.tf
│   │       ├── backend.tf
│   │       ├── globalprotect_ips.tf
│   │       ├── ip_blocklist_sec.tf
│   │       └── main.tf
```