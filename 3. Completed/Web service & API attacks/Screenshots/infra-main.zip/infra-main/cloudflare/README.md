# GitOps IaC for Cloudflare resources

GitOps repository to provision and manage centrally Cloudflare resources via Terraform. The repository uses Atlantis, a Terraform Pull Request Automator, and CODEOWNERS to create an automated approval flow to provision Cloudflare resources via Terraform.

## Supported resources.

Currently, we support several Cloudflare resources. The idea is to add support to more resources once that is needed. We support all the known-used resources. Here is a list:

* Zones
* Records
* WAF - Firewall rules
* Page Rules
* Cloudflare access - Applications
* Cloudflare access - Policies
* Cloudflare access - Groups
* IP lists (Account level)

## Repository organization. 

The repository follows a folder structure to provision the different resources. We decided to split it and group it as the current Cloudflare API. The `zones` resources are located in the zones folder, account-level resources in the `account` folder, and Access resources under the `access` folder.

When it comes to `zones` and `access` there are global resources and 

Each one of the resources typically contains three files: `backend.tf`, `main.tf` and `variables.tf`. There are exceptions, such as large zones where variables are split by record type; IP lists are also split by group.

* **backend.tf:** The backend information contains all the information regarding where the state file is stored for each group of resources. Each one of the resources/modules has its own state file. State files are hosted on the same backend and organized through a folder structure.

* **main.tf:** The module definition contains the source of the module, and all the variables need it to provision the resources. Modules are located centrally in the `moonpay/terraform-modules` repository. Usually, they don't require to be changed to add new resources. If you are dealing with a large zone or IP list, split variables into different files. You may edit the main definition to add the new variable file to be processed by the module.

* **variables.tf:** A variable file containing all the information about the currently provisioned resources. If you want to add a new resource, you should add the corresponding variable block to the desired resource. In this document, you will find several examples of how to provision new resources.