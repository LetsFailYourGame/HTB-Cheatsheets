# Modify/Create a new Cloudflare Access application + policies:

Cloudflare Access applications and their linked policies can be found in `cloudflare/access/applications/APP_NAME/variables.tf`. You should create a new folder in `access/applications/APP_NAME` to create a new application. The folder should contain: `main.tf` with the module definition, `backend.tf` with the backend information, and `variables.tf` with the application and policies definition.

**NOTE:** If you copy an existing application, be sure to change the backend path.

If you just want to modify one existing application or its policies, you should edit the corresponding app at `cloudflare/access/applications/APP_NAME/variables.tf`.

This module uses two submodules to create the resources. This is due to a restriction on the Cloudflare provider, as currently, there is no data source for Cloudflare Access Applications. As policies are linked to apps, you need the `app_id` to create the policy and application relationship. Keeping the two resources in the same module, we can reference the `app_id` from the app submodule in the policy module.

### Applications

To define a new Cloudflare Access Application, you can use the following variables:

| Variables                  | Description                                                                                                                                                                |
|----------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| name                       | Friendly name of the Access Application.                                                                                                                                   |
| domain                     | The complete URL of the asset you wish to put Cloudflare Access in front of. Can include subdomains or paths. Or both.                                                     |
| type                       | The application type. Defaults to self_hosted. Valid values are self_hosted, ssh, vnc, file or bookmark.                                                                   |
| session_duration           | How often a user will be forced to re-authorise. Must be in the format "48h" or "2h45m". Valid time units are ns, us (or µs), ms, s, m, h. Defaults to 24h.                |
| cors_headers               | CORS configuration for the Access Application. See below for reference structure.                                                                                          |
| allowed_idps               | The identity providers selected for the application.                                                                                                                       |
| auto_redirect_to_identity  | Option to skip identity provider selection if only one is configured in allowed_idps. Defaults to false (disabled).                                                        |
| enable_binding_cookie      | Option to provide increased security against compromised authorization tokens and CSRF attacks by requiring an additional "binding" cookie on requests. Defaults to false. |
| custom_deny_message        | Option that returns a custom error message when a user is denied access to the application.                                                                                |
| custom_deny_url            | Option that redirects to a custom URL when a user is denied access to the application.                                                                                     |
| app_launcher_visible       | Option to show/hide applications in App Launcher. Defaults to true.                                                                                                        |
| skip_interstitial          | Option to skip the authorization interstitial when using the CLI.                                                                                                          |
| logo_url                   | Image URL for the logo shown in the app launcher dashboard.                                                                                                                |
| same_site_cookie_attribute | Defines the same-site cookie setting for access tokens. Valid values are none, lax, and strict.                                                                            |
| http_only_cookie_attribute | Option to add the HttpOnly cookie flag to access tokens.                                                                                                                   |
| service_auth_401_redirect  | Option to return a 401 status code in service authentication rules on failed requests.                                                                                     |

**CORS Block**

| Variables         | Description                                                                                                                        |
|-------------------|------------------------------------------------------------------------------------------------------------------------------------|
| allowed_methods   | List of methods to expose via CORS.                                                                                                |
| allowed_origins   | List of origins permitted to make CORS requests.                                                                                   |
| allowed_headers   | List of HTTP headers to expose via CORS.                                                                                           |
| allow_all_methods | Boolean value to determine whether all methods are exposed.                                                                        |
| allow_all_origins | Boolean value to determine whether all origins are permitted to make CORS requests.                                                |
| allow_all_headers | Boolean value to determine whether all HTTP headers are exposed.                                                                   |
| allow_credentials | Boolean value to determine if credentials (cookies, authorization headers, or TLS client certificates) are included with requests. |
| max_age           | Integer representing the maximum time a preflight request will be cached.                                                          |


To add a new Cloudflare Access Application, create a new pull request adding a configuration block to the `cloudflare/access/applications/APP_NAME/variables.tf` file. Resource identifiers are uniques. Example:

```
variable "applications" {
  default = {
    test-moonpay-test-com = {
      name                       = "test.moonpay-test.com"
      domain                     = "test.moonpay-test.com"
      allowed_idps               = []
      auto_redirect_to_identity  = false
      session_duration           = "24h"
      http_only_cookie_attribute = false
      type                       = "self_hosted"
      app_launcher_visible       = true
    }
  }
}
```


### Policies

To define a new Cloudflare Access Policy, you can use the following variables:

| Variables                      | Description                                                                                                           |
|--------------------------------|-----------------------------------------------------------------------------------------------------------------------|
| decision                       | Defines the action Access will take if the policy matches the user. Allowed values: allow, deny, non_identity, bypass |
| name                           | Friendly name of the Access Application.                                                                              |
| precedence                     | The unique precedence for policies on a single application. Integer.                                                  |
| purpose_justification_required | Boolean of whether to prompt the user for a justification for accessing the resource.                                 |
| purpose_justification_prompt   | String to present to the user when purpose justification is enabled.                                                  |
| require                        | A series of access conditions, see Access Groups.                                                                     |
| exclude                        | A series of access conditions, see Access Groups.                                                                     |
| include                        | A series of access conditions, see Access Groups.                                                                     |
| approval_group                 | List of approval group blocks for configuring additional approvals (refer to the nested schema).                      |

**Include, exclude and require conditions**

| Variables               | Description                                                                                                                                                                                             |
|-------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| ip                      | A list of IP addresses or ranges. Example: ip = ["1.2.3.4", "10.0.0.0/2"]                                                                                                                               |
| email                   | A list of email addresses. Example: email = ["test@example.com"]                                                                                                                                        |
| email_domain            | A list of email domains. Example: email_domain = ["example.com"]                                                                                                                                        |
| service_token           | A list of service token ids. Example: service_token = [cloudflare_access_service_token.demo.id]                                                                                                         |
| any_valid_service_token | Boolean indicating if allow all tokens to be granted. Example: any_valid_service_token = true                                                                                                           |
| group                   | A list of access group ids. Example: group = [cloudflare_access_group.demo.id]                                                                                                                          |
| everyone                | Boolean indicating permitting access for all requests. Example: everyone = true                                                                                                                         |
| certificate             | Whether to use mTLS certificate authentication.                                                                                                                                                         |
| common_name             | Use a certificate common name to authenticate with.                                                                                                                                                     |
| auth_method             | A string identifying the authentication method code. The list of codes are listed here: https://tools.ietf.org/html/rfc8176#section-2. Custom values are also supported. Example: auth_method = ["swk"] |
| geo                     | A list of country codes. Example: geo = ["US"]                                                                                                                                                          |
| login_method            | A list of identity provider ids. Example: login_method = [cloudflare_access_identity_provider.my_idp.id]                                                                                                |
| device_posture          | A list of device_posture integration_uids. Example: device_posture = [cloudflare_device_posture_rule.my_posture_rule.id]                                                                                |
| gsuite                  | Use GSuite as the authentication mechanism.                                                                                                                                                             |
| github                  | Use a GitHub organization as the include condition.                                                                                                                                                     |
| azure                   | Use Azure AD as the include condition.                                                                                                                                                                  |
| okta                    | Use Okta as the include condition.                                                                                                                                                                      |
| saml                    | Use an external SAML setup as the include condition                                                                                                                                                     |


To add a new Cloudflare Access Policy, create a new pull request adding a configuration block to the `cloudflare/access/applications/APP_NAME/variables.tf` file. Resource identifiers are uniques. Example:

```
variable "policies" {
  default = {
    policy-allow-all-test = {
      name       = "Allow All test"
      precedence = 1
      decision   = "allow"

      include = {
        group = ["c8fe58ec-720a-4ac9-b691-33451e85d78dd"]
      }
    }

  }
}
```

**NOTE:** Cloudflare Access Groups need to be referenced by the ID. Currently, there is no data source for groups. You will find a relationship between IDs and names in the variable file.
