# Adding a new Cloudflare Access group

Cloudflare Access groups can be found in `cloudflare/access/groups/variables.tf`. To define a new Cloudflare Access Group, you can use the following variables:

| Variables | Description                                             |
|-----------|---------------------------------------------------------|
| name      | (Required) Friendly name of the Access Group.                      |
| require   | (Optional) A series of access conditions, see below for full list. |
| exclude   | (Optional) A series of access conditions, see below for full list. |
| include   | (Required) A series of access conditions, see below for full list. |

**Include, exclude and require conditions**

| Variables               | Description                                                                                                                                                                                             |
|-------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| ip                      | A list of IP addresses or ranges. Example: ip = ["1.2.3.4", "10.0.0.0/2"]                                                                                                                               |
| email                   | A list of email addresses. Example: email = ["test@example.com"]                                                                                                                                        |
| email_domain            | A list of email domains. Example: email_domain = ["example.com"]                                                                                                                                        |
| service_token           | A list of service token ids. Example: service_token = [cloudflare_access_service_token.demo.id]                                                                                                         |
| any_valid_service_token | Boolean indicating if allow all tokens to be granted. Example: any_valid_service_token = true                                                                                                           |
| group                   | A list of access group ids. Example: group = [cloudflare_access_group.demo.id]                                                                                                                          |
| everyone                | Boolean indicating permitting access for all requests. Example: everyone = true                                                                                                                         |
| certificate             | Whether to use mTLS certificate authentication.                                                                                                                                                         |
| common_name             | Use a certificate common name to authenticate with.                                                                                                                                                     |
| auth_method             | A string identifying the authentication method code. The list of codes are listed here: https://tools.ietf.org/html/rfc8176#section-2. Custom values are also supported. Example: auth_method = ["swk"] |
| geo                     | A list of country codes. Example: geo = ["US"]                                                                                                                                                          |
| login_method            | A list of identity provider ids. Example: login_method = [cloudflare_access_identity_provider.my_idp.id]                                                                                                |
| device_posture          | A list of device_posture integration_uids. Example: device_posture = [cloudflare_device_posture_rule.my_posture_rule.id]                                                                                |
| gsuite                  | Use GSuite as the authentication mechanism.                                                                                                                                                             |
| github                  | Use a GitHub organization as the include condition.                                                                                                                                                     |
| azure                   | Use Azure AD as the include condition.                                                                                                                                                                  |
| okta                    | Use Okta as the include condition.                                                                                                                                                                      |
| saml                    | Use an external SAML setup as the include condition                                                                                                                                                     |


To add a new Cloudflare Access group, create a new pull request adding a configuration block to the `cloudflare/access/groups/variables.tf` file. Resource identifiers are uniques. Example:

```
variable "groups" {
  default = {
    all-moonpay = {
      name = "All MoonPay: employees + contractors"

      include = {
        okta = {
          name = ["all-moonpay"]
        }
      }
    },
    test-group = {
      name = "Test Group"

      include = {
        okta = {
          name = ["Dept-Engineering"]
        }
      }
    },
  }
}
```
