# Cloudflare Access

Cloudflare Access resources are split into `applications` and `groups`. Inside the applications folder, there is a folder for each existing application. The application's name identifies the folder. Otherwise, for the group module, you will find all the files at the root of the folder.

Two submodules form the application module. The first submodule deals with application creation. The second submodule is used to provide the different policies attached to an application. This is transparent for the user as the module definition includes the variables for the two submodules but is something to consider when deploying new applications or rules.


The folder structure looks like that:

```
├── cloudflare
│   ├── access
│   │   ├── applications
│   │   │   ├── buy-moonpay-staging-com
│   │   │   │   ├── backend.tf
│   │   │   │   ├── main.tf
│   │   │   │   └── variables.tf
│   │   └── groups
│   │       ├── backend.tf
│   │       ├── main.tf
│   │       └── variables.tf
```


