# pip install boto3 pycryptodome
from pprint import pprint

import boto3
import botocore
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad


# user_id must be a unique user identifier
def moonpay_server_login(user_id):
    # We authenticate user and return the AWS Credentials
    server_session = boto3.Session(profile_name="moonpay-development")
    cognito_identity = server_session.client("cognito-identity", region_name="eu-west-1")
    sts = server_session.client("sts", region_name="eu-west-1")

    resp = cognito_identity.get_open_id_token_for_developer_identity(
        IdentityPoolId="eu-west-1:f3166d4e-ca33-47c1-87d1-dbd1421422fb",
        Logins={
            "com.moonpay.cognito.bridge": user_id
        }
    )

    web_identity_token = resp["Token"]
    identity_id = resp["IdentityId"]

    resp = sts.assume_role_with_web_identity(
        RoleSessionName=identity_id.replace(":", ""),
        RoleArn='arn:aws:iam::583306400178:role/poc-i-dont-have-wallet',
        WebIdentityToken=web_identity_token
    )
    credentials = resp["Credentials"]

    return identity_id, boto3.Session(
        aws_access_key_id=credentials["AccessKeyId"],
        aws_secret_access_key=credentials["SecretAccessKey"],
        aws_session_token=credentials["SessionToken"],
    )


print("### USERS LOGIN ###")
user_1_sub, user_1_session = moonpay_server_login("user-1")
user_2_sub, user_2_session = moonpay_server_login("user-2")
print("user_1_sub", user_1_sub)
print("user_2_sub", user_2_sub)

print("\n\n### USER 1 Encrypts Wallet ###")
resp = user_1_session.client("kms", region_name="eu-west-1").generate_data_key(
    KeyId="c5f58d12-ab88-412c-8266-50352be5315f",
    EncryptionContext={"sub": user_1_sub},
    KeySpec="AES_256",
)
generate_data_key_plain_text_user_1 = resp["Plaintext"]
generate_data_key_cypher_text_blob_user_1 = resp["CiphertextBlob"]
print(f"Generate Data Key\nPlain text: {generate_data_key_plain_text_user_1}\nCipher text Blob: {generate_data_key_cypher_text_blob_user_1}\n----")

wallet_user_1 = b"this is my super secret wallet"
iv = get_random_bytes(16)
encrypted_wallet_user_1 = AES.new(generate_data_key_plain_text_user_1, mode=AES.MODE_CBC, iv=iv).encrypt(pad(wallet_user_1, 16))
print(f"Wallet: {wallet_user_1}\nEncrypted wallet: {encrypted_wallet_user_1}")

print("\n\n### USER 1 Decrypts wallet ###")
resp = user_1_session.client("kms", region_name="eu-west-1").decrypt(
    CiphertextBlob=generate_data_key_cypher_text_blob_user_1,
    EncryptionContext={"sub": user_1_sub},
    KeyId="c5f58d12-ab88-412c-8266-50352be5315f",
    EncryptionAlgorithm="SYMMETRIC_DEFAULT",
)
decrypted_cypher_text_blob_user_1 = resp["Plaintext"]
print(
    "Decrypt generate_data_key_cypher_text_blob_user_1 and check if match the generate_data_key_plain_text_user_1 Expected: True, Got: ",
    decrypted_cypher_text_blob_user_1 == generate_data_key_plain_text_user_1,
)
print(f"decrypted_cypher_text_blob_user_1: {decrypted_cypher_text_blob_user_1}\n----")
decrypted_wallet_user_1 = unpad(AES.new(decrypted_cypher_text_blob_user_1, mode=AES.MODE_CBC, iv=iv).decrypt(encrypted_wallet_user_1), 16)
print(
    "Decrypt encrypted_wallet_user_1 using decrypted_cypher_text_blob_user_1 and check if match the wallet_user_1 Expected: True, Got: ",
    decrypted_wallet_user_1 == wallet_user_1,
)
print(f"decrypted_wallet_user_1: {decrypted_wallet_user_1}")

print("\n\n### USER 2 Decrypts USER 1 wallet ###")
try:
    resp = user_2_session.client("kms", region_name="eu-west-1").decrypt(
        CiphertextBlob=generate_data_key_cypher_text_blob_user_1,
        EncryptionContext={"sub": user_1_sub},
        KeyId="c5f58d12-ab88-412c-8266-50352be5315f",
        EncryptionAlgorithm="SYMMETRIC_DEFAULT",
    )

    print("ALERT: Decrypting generate_data_key_cypher_text_blob_user_1 from user_2. Expected: Exception, Got: decrypted value")
except botocore.exceptions.ClientError:
    print("Decrypting generate_data_key_cypher_text_blob_user_1 from user_2. Expected: Exception, Got: Exception")

print("\n\n### USER 2 GenerateDataKey using USER 1 sub ###")
try:
    resp = user_2_session.client("kms", region_name="eu-west-1").generate_data_key(
        KeyId="c5f58d12-ab88-412c-8266-50352be5315f",
        EncryptionContext={"sub": user_1_sub},
        KeySpec="AES_256",
    )

    print("ALERT: USER 2 GenerateDataKey using USER 1 sub. Expected: Exception, Got: Data Key")
except botocore.exceptions.ClientError:
    print("USER 2 GenerateDataKey using USER 1 sub. Expected: Exception, Got: Exception")
