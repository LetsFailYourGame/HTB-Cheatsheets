
# MoonPay Infrastructure Configuration Management

This repo contains infrastructure-as-code definitions for various MoonPay infrastructure resources. Atlantis, the Terraform :robot: is managed by team-sre@moonpay.com, but resources are owned by each specific team. See [CODEOWNERS][codeowners] for more specific implementations.

| Software                      | Supported version |
|-------------------------------|-------------------|
| Terraform                     | v1.1.8            |

## Repository structure

 * `aws/` - [AWS][aws] organization, accounts, and resources
 * `cloudflare/` - [Cloudflare][cf] related configuration
 * `datadog/` - [DataDog][dd] infrastructure dashboards, alerts, webhooks and log indexes
 * `gcp/` - [Google Cloud Platform][gcp] organization and projects
 * `github/` - [GitHub][github] teams membership definitions
 * `pagerduty/` - [PagerDuty][pd] schedules and escalation policies
 * `vercel/` - [Vercel][vercel] projects (sites)

## Making changes

1. Open a Pull Request with your changes against `main` branch. This will automatically add appropriate (SRE, ProdSec) team as reviewers. Terraform integration (Atlantis) will automatically run `terraform plan` and add comment with plan output to the pull request. 
2. One PR is approved, run `atlantis apply`. This will apply changes to the managed infrastructure. Output will be added as a PR comment.
3. After terraform code is applied, merge code into `main` branch.

## Useful resources

* [GCP: Understanding Roles](https://cloud.google.com/iam/docs/understanding-roles)
* [AWS: IAM roles](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles.html)
* [Terraform: GCP Provider](https://registry.terraform.io/providers/hashicorp/google/latest/docs)
* [Terraform: AWS provider](https://registry.terraform.io/providers/hashicorp/aws/latest/docs)
* [Terraform: CloudFlare provider](https://registry.terraform.io/providers/cloudflare/cloudflare/latest/docs)

[aws]: https://moonpay.awsapps.com/start/
[cf]: https://dash.cloudflare.com
[codeowners]: https://github.com/moonpay/infra/blob/main/CODEOWNERS
[dd]: https://app.datadoghq.com/apm/home
[gcp]: https://console.cloud.google.com
[github]: https://github.com/orgs/moonpay/teams
[pd]: https://moonpay.pagerduty.com
[vercel]: https://vercel.com/moonpay
