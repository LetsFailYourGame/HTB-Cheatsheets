# Google Cloud organizational IAM configuration
Code in this repository manages [Google Cloud IAM bindings](https://cloud.google.com/iam/docs/overview) in Moonpay Google Cloud organization hierarchy (organization and folder level).

IAM bindings allow speciefied IAM principal to perfomed actions defined in a specified role (containing IAM permissions) or a specified resource (in case of this repository, in the entire organization or specified folder)

IAM bindings can be defined on organizational, folder or project levels. This repository contains 2 folder:
* `organization/` - Contains IAM bindings defined on GCP organizational level (root)
* `folders/`      - Contains IAM bindings defined on GCP folder level

## Organizational hierarchy structure
[Organizational hierarchy design](https://cloud.google.com/docs/enterprise/best-practices-for-enterprise-organizations#define-hierarchy) is designed in a following fashion:

* Top level folders are dedicated as a dedicated team nodes
* Folders in levels below top level team folders serve purpose of logical split/IAM/policy management

IAM bindings are inherited according to it's [inheritance system](https://cloud.google.com/iam/docs/resource-hierarchy-access-control)

## Adding an IAM binding
In an appropriate directory in this folder (`folders` or `organization`) update configuration file(s):

``` hcl
variable "bindings" {
  default = {
   # moonpay.com domain (all users)
    "domain:moonpay.com" = {
      roles = [
        "roles/run.viewer",
      ]
    },
    # team-sre@moonpay.com group
    "group:team-sre@moonpay.com" = {
      roles = [
        "roles/dns.reader",
      ]
    },
    # Google Cloud service account
    "serviceAccount:service-account@moonpay-project.iam.gserviceaccount.com" = {
      roles = [
        "roles/container.viewer",
      ]
    },
    # User
    "user:myname@moonpay.com" = {
      roles = [
        "roles/cloudsql.viewer",
      ]
    }
  }
}
```

# Useful resources

* [GCP: IAM Overview](https://cloud.google.com/iam/docs/overview)