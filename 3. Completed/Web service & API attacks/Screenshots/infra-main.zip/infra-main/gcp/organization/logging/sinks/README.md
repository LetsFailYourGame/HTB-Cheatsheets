<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.1.0 |
| <a name="requirement_google"></a> [google](#requirement\_google) | ~> 4.18.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | 4.18.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_destination"></a> [destination](#module\_destination) | terraform-google-modules/log-export/google//modules/storage | n/a |
| <a name="module_log_export"></a> [log\_export](#module\_log\_export) | terraform-google-modules/log-export/google | n/a |
| <a name="module_pubsub_destination"></a> [pubsub\_destination](#module\_pubsub\_destination) | terraform-google-modules/log-export/google//modules/pubsub | n/a |
| <a name="module_pubsub_log_export"></a> [pubsub\_log\_export](#module\_pubsub\_log\_export) | terraform-google-modules/log-export/google | n/a |

## Resources

| Name | Type |
|------|------|
| [google_secret_manager_secret_version.datadog_api_key](https://registry.terraform.io/providers/hashicorp/google/latest/docs/data-sources/secret_manager_secret_version) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_gcs_log_sinks"></a> [gcs\_log\_sinks](#input\_gcs\_log\_sinks) | Log sinks details | `map(any)` | <pre>{<br>  "full-org-no-filters": {<br>    "filter": "",<br>    "include_children": true,<br>    "lifecycle_rules": [<br>      {<br>        "action": {<br>          "type": "Delete"<br>        },<br>        "condition": {<br>          "age": 1095,<br>          "with_state": "ANY"<br>        }<br>      },<br>      {<br>        "action": {<br>          "storage_class": "COLDLINE",<br>          "type": "SetStorageClass"<br>        },<br>        "condition": {<br>          "age": 180,<br>          "with_state": "ANY"<br>        }<br>      }<br>    ],<br>    "location": "europe-west1",<br>    "log_sink_name": "org-no-filter-export",<br>    "parent_resource_id": "302853500510",<br>    "parent_resource_type": "organization",<br>    "project_id": "moonpay-sre",<br>    "storage_bucket_name": "org-no-filter-export",<br>    "unique_writer_identity": true<br>  },<br>  "org-admin-activity": {<br>    "filter": "LOG_ID(\"cloudaudit.googleapis.com/activity\") OR LOG_ID(\"cloudaudit.googleapis.com/data_access\") OR LOG_ID(\"externalaudit.googleapis.com/activity\") OR LOG_ID(\"cloudaudit.googleapis.com/system_event\") OR LOG_ID(\"externalaudit.googleapis.com/system_event\") OR LOG_ID(\"cloudaudit.googleapis.com/access_transparency\") OR LOG_ID(\"externalaudit.googleapis.com/access_transparency\")",<br>    "include_children": true,<br>    "lifecycle_rules": [<br>      {<br>        "action": {<br>          "type": "Delete"<br>        },<br>        "condition": {<br>          "age": 365,<br>          "with_state": "ANY"<br>        }<br>      },<br>      {<br>        "action": {<br>          "storage_class": "COLDLINE",<br>          "type": "SetStorageClass"<br>        },<br>        "condition": {<br>          "age": 180,<br>          "with_state": "ANY"<br>        }<br>      }<br>    ],<br>    "location": "europe-west1",<br>    "log_sink_name": "splunk-org-admin-export",<br>    "parent_resource_id": "302853500510",<br>    "parent_resource_type": "organization",<br>    "project_id": "moonpay-sre",<br>    "storage_bucket_name": "splunk-org-admin-export",<br>    "unique_writer_identity": false<br>  }<br>}</pre> | no |
| <a name="input_pubsub_log_sinks"></a> [pubsub\_log\_sinks](#input\_pubsub\_log\_sinks) | PubSub Log Sinks | `map(any)` | <pre>{<br>  "full-org-no-filters": {<br>    "filter": "",<br>    "include_children": true,<br>    "log_sink_name": "datadog-org-no-filter-export",<br>    "parent_resource_id": "302853500510",<br>    "parent_resource_type": "organization",<br>    "project_id": "moonpay-logs",<br>    "pubsub_topic_name": "datadog-org-no-filter-export",<br>    "push_endpoint": "https://gcp-intake.logs.datadoghq.com/api/v2/logs?dd-protocol=gcp&dd-api-key=",<br>    "unique_writer_identity": true<br>  },<br>  "org-admin-activity": {<br>    "filter": "LOG_ID(\"cloudaudit.googleapis.com/activity\") OR LOG_ID(\"cloudaudit.googleapis.com/data_access\") OR LOG_ID(\"externalaudit.googleapis.com/activity\") OR LOG_ID(\"cloudaudit.googleapis.com/system_event\") OR LOG_ID(\"externalaudit.googleapis.com/system_event\") OR LOG_ID(\"cloudaudit.googleapis.com/access_transparency\") OR LOG_ID(\"externalaudit.googleapis.com/access_transparency\")",<br>    "include_children": true,<br>    "log_sink_name": "datadog-org-admin-export",<br>    "parent_resource_id": "302853500510",<br>    "parent_resource_type": "organization",<br>    "project_id": "moonpay-logs",<br>    "pubsub_topic_name": "datadog-org-admin-export",<br>    "push_endpoint": "https://gcp-intake.logs.datadoghq.com/api/v2/logs?dd-protocol=gcp&dd-api-key=",<br>    "unique_writer_identity": true<br>  }<br>}</pre> | no |

## Outputs

No outputs.
<!-- END_TF_DOCS -->