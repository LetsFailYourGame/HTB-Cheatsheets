# Google Cloud organization folder management
Code in this repository [manages folders](https://cloud.google.com/resource-manager/docs/cloud-platform-resource-hierarchy) in Moonpay Google Cloud organization hierarchy.

Configuration is contained in [variables.tf](variables.tf) which defines all folders and their parents (other folders or an organization).

## Organizational hierarchy structure
[Organizational hierarchy design](https://cloud.google.com/docs/enterprise/best-practices-for-enterprise-organizations#define-hierarchy) is designed in a following fashion:

* Top level folders are dedicated as a dedicated team nodes
* Folders in levels below top level team folders serve purpose of logical split/IAM management for inherited roles.

## Adding a new folder
Update [variables.tf](variables.tf) file and add folder definition as in example below:
``` hcl
variable "folders" {
  type = map(object({ parent=string }))
  description = "Folder names and parent folder names"
  default = {
    # Top-level folders in the GCP resource hierarchy
    ...
    "team-<new>" = {
      "parent" = "organizations/302853500510"
    },


    # 
    # Subfolder section
    # 
    "<new-folder-id>" = {
      "parent" = "folders/<parent_folder_id>"
    }
  }
}

```

# Useful resources

* [GCP: Resource hierarchy](https://cloud.google.com/resource-manager/docs/cloud-platform-resource-hierarchy)