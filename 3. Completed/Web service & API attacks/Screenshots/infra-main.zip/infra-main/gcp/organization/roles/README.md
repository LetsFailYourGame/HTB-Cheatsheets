# Google Cloud organizational roles configuration
Code in this repository [manages custom roles](https://cloud.google.com/iam/docs/creating-custom-roles) in Google Cloud.

Custom role configuration is plit into multiple files along the lines of team responsibility ([roles_security.tf](roles_security.tf), [roles_sre.tf](roles_sre.tf) etc). Each configuration file contains role definitions that are then consolidate and set in Google Cloud.

## Adding a new custom role
Update exiting or add new configuration file. If adding new configuration (variable) file, please make sure variable name in the file is unique and it is added to `data = merge(...)` parameter in [main.tf](main.tf) file.

``` hcl
variable "<my-team>" {
  default = {
    "my-role-identifier-1" = {
      role_name   = "my-new-role-name-1"
      role_title  = "GCP custom role"
      description = "GCP custom role description"
      permissions = [
        "storage.buckets.get",
        "storage.buckets.list",
      ]
    },
    "my-role-identifier-2" = {
      role_name   = "my-new-role-name-2"
      role_title  = "GCP custom role"
      description = "GCP custom role description"
      permissions = [
        "storage.objects.get",
        "storage.objects.list"
      ]
    }
  }
}
```

# Useful resources

* [GCP: Understanding Custom Roles](https://cloud.google.com/iam/docs/understanding-custom-roles)
* [GCP: Understanding Roles](https://cloud.google.com/iam/docs/understanding-roles)