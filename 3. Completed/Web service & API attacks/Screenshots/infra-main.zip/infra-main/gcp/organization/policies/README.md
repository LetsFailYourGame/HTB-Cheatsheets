# Google Cloud organizational policies configuration
Code in this repository manages [Google Cloud organization policies](https://cloud.google.com/resource-manager/docs/cloud-platform-resource-hierarchy) in Moonpay Google Cloud organization hierarchy.

Organizational polies can be defined on organizational, folder or project levels. This repository contains 2 folder:
* `organization/` - Contains organizational policies defined on GCP organizational level (root)
* `folders/`      - Contains organizational policies defined on GCP folder level

List of organizational policies constraints available in Google Cloud: [list](https://cloud.google.com/resource-manager/docs/organization-policy/org-policy-constraints)

## Organizational hierarchy structure
[Organizational hierarchy design](https://cloud.google.com/docs/enterprise/best-practices-for-enterprise-organizations#define-hierarchy) is designed in a following fashion:

* Top level folders are dedicated as a dedicated team nodes
* Folders in levels below top level team folders serve purpose of logical split/IAM/policy management

Organizational policies are inherited according to it's [inheritance system](https://cloud.google.com/resource-manager/docs/organization-policy/overview#inheritance)

## Adding a policy
In an appropriate directory in this folder (`folders` or `organization`) update configuration file(s):

### Add boolean policy
Boolean policy has boolean value `true` or `false` set for `enforced` key.
``` hcl
variable "organization_policies" {
  description = "Organization policies configuration"
  folder      = "folders/940582686346" # OPTIONAL. If this is a folder policy = applied on a folder. If not set, policy applied on organizational level
  default = {
    moonpay-restrict-shared-vpc-project-lien-removal = {
      constraint = "constraints/compute.restrictXpnProjectLienRemoval"
      enforced   = true
    },
    ...
  }
}
```
### Add list constraint policy
Google cloud organizational policies that support list constraints 
``` hcl
variable "organization_policies" {
  default = {
    moonpay-organization-trusted-images = {
      constraint = "constraints/compute.trustedImageProjects"
      folder      = "folders/940582686346" # OPTIONAL. If this is a folder policy = applied on a folder. If not set, policy applied on organizational level
      allow = [                         # Can also be "deny" policy
        "projects/centos-cloud",
        "projects/cos-cloud",
      ]
    },
  }
}
```

# Useful resources

* [GCP: Creating and managing organization policies](https://cloud.google.com/resource-manager/docs/organization-policy/creating-managing-policies#inheriting_organization_policy)