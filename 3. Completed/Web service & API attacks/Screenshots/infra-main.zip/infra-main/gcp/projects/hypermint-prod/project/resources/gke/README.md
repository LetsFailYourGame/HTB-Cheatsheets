# GKE cluster for SRE tooling
Code defines private GKE cluster used by the SRE for their tooling.
<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.1.8 |
| <a name="requirement_google"></a> [google](#requirement\_google) | >= 4.18.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | 4.52.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_gke"></a> [gke](#module\_gke) | terraform-google-modules/kubernetes-engine/google//modules/beta-private-cluster | ~> 25.0.0 |

## Resources

| Name | Type |
|------|------|
| [google_pubsub_topic.gke_notifications](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/pubsub_topic) | resource |
| [google_client_config.default](https://registry.terraform.io/providers/hashicorp/google/latest/docs/data-sources/client_config) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_backup_regions"></a> [backup\_regions](#input\_backup\_regions) | The regions to backup the cluster | `list` | <pre>[<br>  "europe-southwest1",<br>  "us-central1"<br>]</pre> | no |
| <a name="input_cluster_autoscaling"></a> [cluster\_autoscaling](#input\_cluster\_autoscaling) | Cluster autoscaling configuration. See [more details](https://cloud.google.com/kubernetes-engine/docs/reference/rest/v1beta1/projects.locations.clusters#clusterautoscaling) | <pre>object({<br>    enabled             = bool<br>    autoscaling_profile = string<br>    min_cpu_cores       = number<br>    max_cpu_cores       = number<br>    min_memory_gb       = number<br>    max_memory_gb       = number<br>    gpu_resources       = list(object({ resource_type = string, minimum = number, maximum = number }))<br>    auto_repair         = bool<br>    auto_upgrade        = bool<br>  })</pre> | <pre>{<br>  "auto_repair": true,<br>  "auto_upgrade": true,<br>  "autoscaling_profile": "BALANCED",<br>  "enabled": false,<br>  "gpu_resources": [],<br>  "max_cpu_cores": 96,<br>  "max_memory_gb": 384,<br>  "min_cpu_cores": 32,<br>  "min_memory_gb": 128<br>}</pre> | no |
| <a name="input_cluster_name"></a> [cluster\_name](#input\_cluster\_name) | A suffix to append to the default cluster name | `string` | `"prod"` | no |
| <a name="input_disable_default_snat"></a> [disable\_default\_snat](#input\_disable\_default\_snat) | Whether to disable the default SNAT to support the private use of public IP addresses | `string` | `true` | no |
| <a name="input_enable_dataplane_v2"></a> [enable\_dataplane\_v2](#input\_enable\_dataplane\_v2) | Whether enable\_dataplane\_v2 is enabled | `bool` | `true` | no |
| <a name="input_enable_horizontal_pod_autoscaling"></a> [enable\_horizontal\_pod\_autoscaling](#input\_enable\_horizontal\_pod\_autoscaling) | Enable horizontal pod autoscaler. | `bool` | `true` | no |
| <a name="input_enable_l4_ilb_subsetting"></a> [enable\_l4\_ilb\_subsetting](#input\_enable\_l4\_ilb\_subsetting) | Enable L4 ILB Subsetting on the cluster | `string` | `true` | no |
| <a name="input_enable_private_endpoint"></a> [enable\_private\_endpoint](#input\_enable\_private\_endpoint) | Whether control plane is publically accessible | `bool` | `false` | no |
| <a name="input_enable_private_nodes"></a> [enable\_private\_nodes](#input\_enable\_private\_nodes) | Whether GKE nodes are private (no public IP) | `bool` | `true` | no |
| <a name="input_enable_shielded_nodes"></a> [enable\_shielded\_nodes](#input\_enable\_shielded\_nodes) | Whether enable\_shielded\_nodes is enabled | `bool` | `true` | no |
| <a name="input_enable_vertical_pod_autoscaling"></a> [enable\_vertical\_pod\_autoscaling](#input\_enable\_vertical\_pod\_autoscaling) | Enable vertical pod autoscaler. | `bool` | `true` | no |
| <a name="input_enable_workload_identity"></a> [enable\_workload\_identity](#input\_enable\_workload\_identity) | Enable workload identity. | `string` | `"enabled"` | no |
| <a name="input_gce_pd_csi_driver"></a> [gce\_pd\_csi\_driver](#input\_gce\_pd\_csi\_driver) | Whether this cluster should enable the Google Compute Engine Persistent Disk Container Storage Interface (CSI) Driver. | `bool` | `true` | no |
| <a name="input_gke_backup_agent_config"></a> [gke\_backup\_agent\_config](#input\_gke\_backup\_agent\_config) | Whether Backup for GKE agent is enabled for this cluster. | `bool` | `true` | no |
| <a name="input_grant_registry_access"></a> [grant\_registry\_access](#input\_grant\_registry\_access) | Enable cluster identity access to container registry in it's project. | `bool` | `true` | no |
| <a name="input_http_load_balancing"></a> [http\_load\_balancing](#input\_http\_load\_balancing) | Enable GCE ingress controller | `bool` | `true` | no |
| <a name="input_ip_range_name_pods"></a> [ip\_range\_name\_pods](#input\_ip\_range\_name\_pods) | The _name_ of the secondary subnet ip range to use for pods | `string` | `"pods"` | no |
| <a name="input_ip_range_name_services"></a> [ip\_range\_name\_services](#input\_ip\_range\_name\_services) | The _name_ of the secondary subnet range to use for services | `string` | `"svc"` | no |
| <a name="input_master_authorized_networks"></a> [master\_authorized\_networks](#input\_master\_authorized\_networks) | List of public IP CIDR ranges allowed to connect to control plane | `list(object({ cidr_block = string, display_name = string }))` | <pre>[<br>  {<br>    "cidr_block": "34.140.248.51/32",<br>    "display_name": "moonpay-prod-gke-prod-1 - cloudflaretunnel"<br>  },<br>  {<br>    "cidr_block": "34.77.238.249/32",<br>    "display_name": "moonpay-prod-gke-prod-2 - cloudflaretunnel"<br>  },<br>  {<br>    "cidr_block": "35.187.169.152/32",<br>    "display_name": "moonpay-sre-gke-tools-1 - cloudflaretunnel + atlantis + argo"<br>  },<br>  {<br>    "cidr_block": "104.199.41.42/32",<br>    "display_name": "moonpay-sre-gke-tools-2 - cloudflaretunnel + atlantis + argo"<br>  },<br>  {<br>    "cidr_block": "208.127.249.250/32",<br>    "display_name": "Spain East 1"<br>  },<br>  {<br>    "cidr_block": "134.238.65.15/32",<br>    "display_name": "Spain East 2"<br>  },<br>  {<br>    "cidr_block": "165.1.148.249/32",<br>    "display_name": "Spain East 3"<br>  },<br>  {<br>    "cidr_block": "165.1.148.250/32",<br>    "display_name": "Spain East 4"<br>  },<br>  {<br>    "cidr_block": "165.1.148.251/32",<br>    "display_name": "Spain East 5"<br>  },<br>  {<br>    "cidr_block": "165.1.148.252/32",<br>    "display_name": "Spain East 6"<br>  },<br>  {<br>    "cidr_block": "134.238.109.77/32",<br>    "display_name": "Spain Central 1"<br>  },<br>  {<br>    "cidr_block": "134.238.109.76/32",<br>    "display_name": "Spain Central 2"<br>  },<br>  {<br>    "cidr_block": "165.1.144.168/32",<br>    "display_name": "Spain Central 3"<br>  },<br>  {<br>    "cidr_block": "165.1.144.169/32",<br>    "display_name": "Spain Central 4"<br>  },<br>  {<br>    "cidr_block": "165.1.144.170/32",<br>    "display_name": "Spain Central 5"<br>  },<br>  {<br>    "cidr_block": "165.1.144.171/32",<br>    "display_name": "Spain Central 6"<br>  },<br>  {<br>    "cidr_block": "130.41.17.5/32",<br>    "display_name": "Andorra 1"<br>  },<br>  {<br>    "cidr_block": "130.41.17.6/32",<br>    "display_name": "Andorra 2"<br>  },<br>  {<br>    "cidr_block": "130.41.17.7/32",<br>    "display_name": "Andorra 3"<br>  },<br>  {<br>    "cidr_block": "130.41.17.8/32",<br>    "display_name": "Andorra 4"<br>  },<br>  {<br>    "cidr_block": "208.127.33.18/32",<br>    "display_name": "Andorra 5"<br>  },<br>  {<br>    "cidr_block": "208.127.33.19/32",<br>    "display_name": "Andorra 6"<br>  },<br>  {<br>    "cidr_block": "165.1.253.249/32",<br>    "display_name": "Canada East 1"<br>  },<br>  {<br>    "cidr_block": "208.127.145.49/32",<br>    "display_name": "Canada East 2"<br>  },<br>  {<br>    "cidr_block": "165.1.255.149/32",<br>    "display_name": "Canada Central 1"<br>  },<br>  {<br>    "cidr_block": "165.1.255.59/32",<br>    "display_name": "Canada Central 2"<br>  },<br>  {<br>    "cidr_block": "208.127.55.170/32",<br>    "display_name": "UK 1"<br>  },<br>  {<br>    "cidr_block": "208.127.55.171/32",<br>    "display_name": "UK 2"<br>  }<br>]</pre> | no |
| <a name="input_master_global_access_enabled"></a> [master\_global\_access\_enabled](#input\_master\_global\_access\_enabled) | Whether the cluster master is accessible globally (from any region) or only within the same region as the private endpoint.. | `bool` | `false` | no |
| <a name="input_master_ipv4_cidr_block"></a> [master\_ipv4\_cidr\_block](#input\_master\_ipv4\_cidr\_block) | The IP address range of the master network. If empty, a range will be automatically chosen with the size of your cluster. | `string` | `"10.135.247.0/28"` | no |
| <a name="input_project_id"></a> [project\_id](#input\_project\_id) | The project ID to host the cluster in | `string` | `"hypermint-prod"` | no |
| <a name="input_region"></a> [region](#input\_region) | The region to host the cluster in | `string` | `"europe-west1"` | no |
| <a name="input_release_channel"></a> [release\_channel](#input\_release\_channel) | GKE release channel. See [more details](https://cloud.google.com/kubernetes-engine/docs/concepts/release-channels) | `string` | `"RAPID"` | no |
| <a name="input_slack_token_name"></a> [slack\_token\_name](#input\_slack\_token\_name) | Google Cloud Secrets manager secret name for the slack token used in notifications | `string` | `"gke_slack_notifications_token"` | no |
| <a name="input_vpc_network_name"></a> [vpc\_network\_name](#input\_vpc\_network\_name) | The VPC network to host the cluster in | `string` | `"gke-vpc"` | no |
| <a name="input_vpc_subnetwork_name"></a> [vpc\_subnetwork\_name](#input\_vpc\_subnetwork\_name) | The subnetwork to host the cluster in | `string` | `"k8s-europe-west1"` | no |
| <a name="input_zones"></a> [zones](#input\_zones) | The zone to host the cluster in (required if is a zonal cluster) | `list(string)` | <pre>[<br>  "europe-west1-b",<br>  "europe-west1-c",<br>  "europe-west1-d"<br>]</pre> | no |

## Outputs

No outputs.
<!-- END_TF_DOCS -->
