## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.1.8 |
| <a name="requirement_google"></a> [google](#requirement\_google) | ~> 4.27 |
| <a name="requirement_google-beta"></a> [google-beta](#requirement\_google-beta) | ~> 4.27 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | ~> 4.27 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_helm_loki"></a> [helm\_loki](#module\_helm\_loki) | git::git@github.com:moonpay/terraform-modules.git//helm/release | v0.3.29 |
| <a name="module_loki-workload-identity"></a> [loki-workload-identity](#module\_loki-workload-identity) | git::git@github.com:moonpay/terraform-modules.git//gcp/workload_identity | v0.3.35 |

## Resources

| Name | Type |
|------|------|
| [google_compute_global_address.loki](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_global_address) | resource |
| [google_storage_bucket.loki_backend](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/storage_bucket) | resource |
| [google_storage_bucket_iam_member.loki-iam](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/storage_bucket_iam_member) | resource |
| [google_client_config.default](https://registry.terraform.io/providers/hashicorp/google/latest/docs/data-sources/client_config) | data source |
| [google_container_cluster.cluster](https://registry.terraform.io/providers/hashicorp/google/latest/docs/data-sources/container_cluster) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cluster_name"></a> [cluster\_name](#input\_cluster\_name) | Kubernetes Cluster name where workload identity will be provision | `string` | `"gke-preprod"` | no |
| <a name="input_environment_name"></a> [environment\_name](#input\_environment\_name) | Name of application environment | `string` | `"preprod"` | no |
| <a name="input_gcs_backend_bucket_name"></a> [gcs\_backend\_bucket\_name](#input\_gcs\_backend\_bucket\_name) | Name of the loki backend GCS bucket | `string` | `"moonpay-loki-backend"` | no |
| <a name="input_gcs_bucket_location"></a> [gcs\_bucket\_location](#input\_gcs\_bucket\_location) | Name of the loki GCS location | `string` | `"EUROPE-WEST1"` | no |
| <a name="input_grafana_workload_identity_svc_account_name"></a> [grafana\_workload\_identity\_svc\_account\_name](#input\_grafana\_workload\_identity\_svc\_account\_name) | Service Account name for workload identity | `string` | `"grafana-wli-sre@moonpay-sre.iam.gserviceaccount.com"` | no |
| <a name="input_kubernetes_namespace"></a> [kubernetes\_namespace](#input\_kubernetes\_namespace) | Kubernetes Namespace to provision workload-identity | `string` | `"logging"` | no |
| <a name="input_project_id"></a> [project\_id](#input\_project\_id) | Google Cloud project ID | `string` | `"moonpay-preprod"` | no |
| <a name="input_project_region"></a> [project\_region](#input\_project\_region) | Google Cloud project region, all resources (where applicable) will be placed in this region | `string` | `"europe-west1"` | no |
| <a name="input_workload_identity_roles"></a> [workload\_identity\_roles](#input\_workload\_identity\_roles) | Roles linked to the workload identity service account. GCP permissions for the app | `list(any)` | `[]` | no |
| <a name="input_workload_identity_svc_account_name"></a> [workload\_identity\_svc\_account\_name](#input\_workload\_identity\_svc\_account\_name) | Service Account name for workload identity | `string` | `"loki-wli-preprod"` | no |

## Outputs

No outputs.

<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.1.8 |
| <a name="requirement_google"></a> [google](#requirement\_google) | ~> 4.27 |
| <a name="requirement_google-beta"></a> [google-beta](#requirement\_google-beta) | ~> 4.27 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | 4.27.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_external-secrets-workload-identity"></a> [external-secrets-workload-identity](#module\_external-secrets-workload-identity) | git::git@github.com:moonpay/terraform-modules.git//gcp/workload_identity | v0.3.35 |
| <a name="module_helm_external_secrets"></a> [helm\_external\_secrets](#module\_helm\_external\_secrets) | git::git@github.com:moonpay/terraform-modules.git//helm/release | v0.3.29 |

## Resources

| Name | Type |
|------|------|
| [google_client_config.default](https://registry.terraform.io/providers/hashicorp/google/latest/docs/data-sources/client_config) | data source |
| [google_container_cluster.cluster](https://registry.terraform.io/providers/hashicorp/google/latest/docs/data-sources/container_cluster) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cluster_name"></a> [cluster\_name](#input\_cluster\_name) | Kubernetes Cluster name where workload identity will be provision | `string` | `"gke-preprod"` | no |
| <a name="input_environment_name"></a> [environment\_name](#input\_environment\_name) | Name of application environment | `string` | `"preprod"` | no |
| <a name="input_kubernetes_namespace"></a> [kubernetes\_namespace](#input\_kubernetes\_namespace) | Kubernetes Namespace to provision workload-identity | `string` | `"external-secrets"` | no |
| <a name="input_project_id"></a> [project\_id](#input\_project\_id) | Google Cloud project ID | `string` | `"moonpay-preprod"` | no |
| <a name="input_project_region"></a> [project\_region](#input\_project\_region) | Google Cloud project region, all resources (where applicable) will be placed in this region | `string` | `"europe-west1"` | no |
| <a name="input_workload_identity_roles"></a> [workload\_identity\_roles](#input\_workload\_identity\_roles) | Roles linked to the workload identity service account. GCP permissions for the app | `list(any)` | `[]` | no |
| <a name="input_workload_identity_svc_account_name"></a> [workload\_identity\_svc\_account\_name](#input\_workload\_identity\_svc\_account\_name) | Service Account name for workload identity | `string` | `"external-secrets-wli-preprod"` | no |

## Outputs

No outputs.
<!-- END_TF_DOCS -->