## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.1.8 |
| <a name="requirement_google"></a> [google](#requirement\_google) | >= 4.27 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | >= 4.27 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [google_compute_security_policy.policy-gke-clusters](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_security_policy) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_policy_description_gke_clusters"></a> [policy\_description\_gke\_clusters](#input\_policy\_description\_gke\_clusters) | n/a | `string` | `"Moonpoay GKE Clusters: moonpay-sre, moonpay-preprod & moonpay-prod"` | no |
| <a name="input_policy_name_gke_clusters"></a> [policy\_name\_gke\_clusters](#input\_policy\_name\_gke\_clusters) | n/a | `string` | `"moonpay-gke-clusters-policy"` | no |
| <a name="input_rules_gke_clusters"></a> [rules\_gke\_clusters](#input\_rules\_gke\_clusters) | Moonpay GKE Clusters Outbound Adresses | <pre>list(object({<br>    description = string<br>    priority    = string<br>    ip_address  = list(string)<br>  }))</pre> | <pre>[<br>  {<br>    "description": "moonpay-sre NAT IP",<br>    "ip_address": [<br>      "104.199.41.42"<br>    ],<br>    "priority": "1000"<br>  },<br>  {<br>    "description": "moonpay-preprod NAT IP",<br>    "ip_address": [<br>      "35.205.30.5"<br>    ],<br>    "priority": "1001"<br>  },<br>  {<br>    "description": "moonpay-prod NAT IP",<br>    "ip_address": [<br>      "34.77.238.249"<br>    ],<br>    "priority": "1002"<br>  }<br>]</pre> | no |

## Outputs

No outputs.
