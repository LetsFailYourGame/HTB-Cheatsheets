# Project related configuration
Code in this folder defines GCP projects and resources and configuration contained in these projects.

**NOTE: Google Cloud project IDs must be globally unique and can not ever be re-used.** In other words, if project with certain ID exists or existed at some point in the past, it will not be possible to create a new project using that ID. **To limit chance of ID collision happening, please create all new project in `moonpay-<project_description>` format**

## Creating a new project
To create a new project, create a new folder in this directory containing 4 files:
* backend.tf
```hcl
terraform {
  backend "gcs" {
    bucket = "moonpay-sre-state"
    prefix = "terraform/gcp/projects/<project_id>/project"
  }
}
```
* requirements.tf
```hcl
terraform {
  required_version = ">= 1.1.8"
}
```
* variables.tf
```hcl
#### EDIT HERE: project ID in moonpay-<project_purpose> format
variable "project_id" {
  type        = string
  description = "The project ID for the new project"
  default     = "moonpay-<project_purpose>"
}

#### EDIT HERE: project name in moonpay-<project_purpose> format. GCP project name is a friendly name, it can be changed later. Recommended leaving this equal to project ID.
variable "project_name" {
  type        = string
  description = "The project name for the new project"
  default     = "moonpay-<project_purpose>"
}

#### Do not edit values below
variable "org_id" {
  type        = string
  description = "The organization ID for the new project"
  default     = "302853500510"
}

variable "billing_account_id" {
  type        = string
  description = "The billing account ID for the new project"
  default     = "018334-678C06-1CBC81"
}

variable "folder_id" {
  type        = string
  description = "The folder ID in which the new project will be created"
  default     = "66497716015"
}

variable "create_project_service_account" {
  type        = bool
  description = "Whether to create a service account for the new project"
  default     = false
}

variable "activate_apis" {
  type        = list(string)
  description = "The APIs to activate for the new project"
  default     = ["container.googleapis.com", "compute.googleapis.com"]
}
```
* main.tf
```hcl
module "project-factory" {
  source  = "terraform-google-modules/project-factory/google"
  version = "~> 13.0.0"

  name              = var.project_name
  project_id        = var.project_id
  random_project_id = false
  org_id            = var.org_id
  billing_account   = var.billing_account_id
  folder_id         = var.folder_id
  lien              = true
  create_project_sa = var.create_project_service_account
  activate_apis     = var.activate_apis
}
```
Standard PR flow (atlantis) with approval will then create your project.