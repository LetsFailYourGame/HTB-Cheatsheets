<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | 4.22.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [google_storage_bucket_iam_member.member_binding](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/storage_bucket_iam_member) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_bucket_iam"></a> [bucket\_iam](#input\_bucket\_iam) | Bucket IAM details | `map(any)` | <pre>{<br>  "artifact_bucket": {<br>    "bucket_name": "eu.artifacts.moonpay-sre.appspot.com",<br>    "identity": "serviceAccount:tf-gke-gke-prod-tq3e@moonpay-prod.iam.gserviceaccount.com",<br>    "role_id": "roles/storage.objectViewer"<br>  },<br>  "artifact_bucket_github_federation": {<br>    "bucket_name": "eu.artifacts.moonpay-sre.appspot.com",<br>    "identity": "serviceAccount:github-artifact-registry-write@moonpay-sre.iam.gserviceaccount.com",<br>    "role_id": "roles/storage.legacyBucketWriter"<br>  },<br>  "artifact_bucket_github_federation_object_admin": {<br>    "bucket_name": "eu.artifacts.moonpay-sre.appspot.com",<br>    "identity": "serviceAccount:github-artifact-registry-write@moonpay-sre.iam.gserviceaccount.com",<br>    "role_id": "roles/storage.objectAdmin"<br>  }<br>}</pre> | no |
| <a name="input_project_id"></a> [project\_id](#input\_project\_id) | n/a | `string` | `"moonpay-sre"` | no |

## Outputs

No outputs.
<!-- END_TF_DOCS -->