# GKE cluster for SRE tooling
Code defines private GKE cluster used by the SRE for their tooling.
<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google"></a> [google](#provider\_google) | 4.31.0 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_vpc"></a> [vpc](#module\_vpc) | terraform-google-modules/network/google | ~> 5.0.0 |

## Resources

| Name | Type |
|------|------|
| [google_compute_address.nat_gw_address](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_address) | resource |
| [google_compute_global_address.ingress_public_address](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_global_address) | resource |
| [google_compute_global_address.private_gcp_services_ip_alloc](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_global_address) | resource |
| [google_compute_router.nat_gw_router](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_router) | resource |
| [google_compute_router_nat.nat_gw_manual_ips](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/compute_router_nat) | resource |
| [google_service_networking_connection.google_svc_connection](https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/service_networking_connection) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_http_load_balancing"></a> [http\_load\_balancing](#input\_http\_load\_balancing) | Enable GCE ingress controller | `bool` | `true` | no |
| <a name="input_ip_range_name_pods"></a> [ip\_range\_name\_pods](#input\_ip\_range\_name\_pods) | The _name_ of the secondary subnet ip range to use for pods | `string` | `"pods"` | no |
| <a name="input_ip_range_name_services"></a> [ip\_range\_name\_services](#input\_ip\_range\_name\_services) | The _name_ of the secondary subnet range to use for services | `string` | `"svc"` | no |
| <a name="input_private_services_connection_alocation_name"></a> [private\_services\_connection\_alocation\_name](#input\_private\_services\_connection\_alocation\_name) | Name of the private services connection subnet allocation | `string` | `"global-psconnect-ip"` | no |
| <a name="input_private_services_connection_cidr"></a> [private\_services\_connection\_cidr](#input\_private\_services\_connection\_cidr) | The CIDR of the private services connection subnet | `string` | `"10.100.248.0"` | no |
| <a name="input_private_services_connection_cidr_length"></a> [private\_services\_connection\_cidr\_length](#input\_private\_services\_connection\_cidr\_length) | The CIDR length of the private services connection subnet | `number` | `21` | no |
| <a name="input_project_id"></a> [project\_id](#input\_project\_id) | The project ID to host the cluster in | `string` | `"moonpay-sre"` | no |
| <a name="input_region"></a> [region](#input\_region) | The region to host the cluster in | `string` | `"europe-west1"` | no |
| <a name="input_secondary_range_pods"></a> [secondary\_range\_pods](#input\_secondary\_range\_pods) | The secondary subnet ip range to use for pods | `string` | `"10.1.0.0/16"` | no |
| <a name="input_secondary_range_services"></a> [secondary\_range\_services](#input\_secondary\_range\_services) | The secondary subnet range to use for services | `string` | `"10.2.0.0/16"` | no |
| <a name="input_vpc_network_name"></a> [vpc\_network\_name](#input\_vpc\_network\_name) | The VPC network to host the cluster in | `string` | `"gke-vpc-tools"` | no |
| <a name="input_vpc_routing_mode"></a> [vpc\_routing\_mode](#input\_vpc\_routing\_mode) | VPC routing mode | `string` | `"GLOBAL"` | no |
| <a name="input_vpc_subnetwork_name"></a> [vpc\_subnetwork\_name](#input\_vpc\_subnetwork\_name) | The subnetwork to host the cluster in | `string` | `"k8s-europe-west1"` | no |

## Outputs

No outputs.
<!-- END_TF_DOCS -->
