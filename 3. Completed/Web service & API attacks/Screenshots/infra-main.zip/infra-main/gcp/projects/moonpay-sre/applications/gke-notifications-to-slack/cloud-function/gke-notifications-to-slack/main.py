import base64
import json
import os
import requests
import sys
import logging
import functions_framework


def process_gke_notification_event(event, slack_channel):
    if "data" not in event:
        logging.error("No event was passed into the function. Exiting.")
        return

    cluster = event["attributes"]["cluster_name"]
    payload = json.loads(event["attributes"]["payload"])
    message = base64.b64decode(event["data"]).decode("utf-8")
    project = event["attributes"]["project_id"]
    slack_data = {
        "username": "GKE Notifications",
        "icon_emoji": ":kubernetes:",
        "channel": slack_channel,
        "attachments": [{'fields': []}]
    }

    if "SecurityBulletinEvent" in event["attributes"]["type_url"]:
        cluster_resource = payload.get("resourceType", "")
        brief_description = payload.get("briefDescription", "")
        bulletin_uri = payload.get("bulletinUri", "")
        severity = payload.get("severity")
        if severity == "CRITICAL":
            severity = f":fire: {severity}"
        elif severity == "HIGH":
            severity = f":bangbang: {severity}"
        elif severity == "MEDIUM":
            severity = f":warning: {severity}"
        else:
            severity = f":question: {severity}"

        affected_supported_minors = payload.get("affectedSupportedMinors", [])
        suggested_upgrade_target = payload.get("suggestedUpgradeTarget", "Unknown")
        cve_ids = payload.get("cveIds", ["Unknown"])
        title = "Security bulletin :eight_spoked_asterisk:"

        slack_data['attachments'].append({"color": "#9733EE"})
        slack_data['attachments'][0]['fields'].append({"title": title})
        slack_data['attachments'][0]['fields'].append({"title": "Project", "value": project, "short": "false"})
        slack_data['attachments'][0]['fields'].append({"title": "Cluster", "value": cluster, "short": "false",})
        slack_data['attachments'][0]['fields'].append({"title": "Severity", "value": severity, "short": "false",})
        slack_data['attachments'][0]['fields'].append({"title": "Update Type", "value": cluster_resource, "short": "false"})
        slack_data['attachments'][0]['fields'].append({"title": "Bulletin URL", "value": bulletin_uri, "short": "false"})
        slack_data['attachments'][0]['fields'].append({"title": "Brief description", "value": brief_description, "short": "false"})
        slack_data['attachments'][0]['fields'].append({"title": "Affected Versions", "value": ", ".join(affected_supported_minors), "short": "false"})
        slack_data['attachments'][0]['fields'].append({"title": "Suggested upgrade", "value": suggested_upgrade_target, "short": "false"})
        slack_data['attachments'][0]['fields'].append({"title": "CVE IDs", "value": ", ".join(cve_ids), "short": "false"})

        return slack_data

    if "UpgradeEvent" in event["attributes"]["type_url"]:
        current_version = payload["currentVersion"]
        cluster_resource = payload.get("resourceType", "")
        start_time = payload["operationStartTime"]
        target_version = payload["targetVersion"]
        title = "GKE Cluster Upgrade Notification :zap:"

        slack_data['attachments'].append({"color": "#9733EE"})
        slack_data['attachments'][0]['fields'].append({"title": title})
        slack_data['attachments'][0]['fields'].append({"title": "Project", "value": project, "short": "false"})
        slack_data['attachments'][0]['fields'].append({"title": "Cluster", "value": cluster, "short": "false",})
        slack_data['attachments'][0]['fields'].append({"title": "Update Type", "value": cluster_resource, "short": "false"})
        slack_data['attachments'][0]['fields'].append({"title": "Current Version", "value": current_version, "short": "false"})
        slack_data['attachments'][0]['fields'].append({"title": "Target Version", "value": target_version, "short": "false"})
        slack_data['attachments'][0]['fields'].append({"title": "Details", "value": message, "short": "false"})

        return slack_data

    # UpgradeAvailableEvent
    if "UpgradeAvailableEvent" in event["attributes"]["type_url"]:
        available_version = payload["version"]
        cluster_resource = payload.get("resourceType", "")
        title = "GKE Cluster Upgrade Available Notification :zap:"

        slack_data['attachments'].append({"color": "#2BB500"})
        slack_data['attachments'][0]['fields'].append({"title": title})
        slack_data['attachments'][0]['fields'].append({"title": "Project", "value": project, "short": "false"})
        slack_data['attachments'][0]['fields'].append({"title": "Cluster", "value": cluster, "short": "false",})
        slack_data['attachments'][0]['fields'].append({"title": "Eligible Resource", "value": cluster_resource, "short": "false"})
        slack_data['attachments'][0]['fields'].append({"title": "Eligible Version", "value": available_version, "short": "false"})
        slack_data['attachments'][0]['fields'].append({"title": "Details", "value": message, "short": "false"})

        return slack_data

    logging.info("Event was neither UpgradeEvent or UpgradeAvailableEvent. Skipping.")

    return None

@functions_framework.http
def main(request):
    slack_webhook_url = os.environ['SLACK_WEBHOOK']
    slack_channel = os.environ['SLACK_NOTIFICATION_CHANNEL']
    app_response = "OK"

    try:
        event = request.get_json(silent=True)
        logging.info(event)
        slack_data = process_gke_notification_event(event["message"], slack_channel)
        if not slack_data:
            return "Event was neither UpgradeEvent or UpgradeAvailableEvent. Skipping."
    except Exception as exception:
        slack_data = {
            "username": "GKE Notifications",
            "icon_emoji": ":kubernetes:",
            "channel": slack_channel,
            "attachments": [
                {
                    "color": "#FF0000",
                    "fields": [
                        {"title": "GKE Notification function failed to decode message, check logs :bangbang:"},
                        {
                            "title": "Message",
                            "value": str(event),
                            "short": "false",
                        },
                    ],
                }
            ],
        }

        logging.error(f"Failed to process the GKE upgrade event '{event}'")
        logging.error(exception)
        app_response = "ERROR"

    byte_length = str(sys.getsizeof(slack_data))
    headers = {
        "Content-Type": "application/json",
        "Content-Length": byte_length,
    }

    try:
        response = requests.post(slack_webhook_url, data=json.dumps(slack_data), headers=headers)
        if response.status_code != 200:
            logging.error(f"Failed to send the notification to slack '{response.status_code, response.text}'")

            raise Exception(response.status_code, response.text)
    except Exception as exception:
        logging.error(f"Failed to process the GKE upgrade event '{event}'")
        logging.error(exception)

        raise exception

    logging.info("GKE Upgrade notification is successfully processed")

    return app_response
