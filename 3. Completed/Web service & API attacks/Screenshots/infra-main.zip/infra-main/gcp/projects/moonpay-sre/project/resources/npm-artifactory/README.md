<!-- BEGIN_TF_DOCS -->
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.1.0 |
| <a name="requirement_google-beta"></a> [google-beta](#requirement\_google-beta) | ~> 4.20.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_google-beta"></a> [google-beta](#provider\_google-beta) | 4.20.0 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [google-beta_google_artifact_registry_repository.npm-moonpay-registry](https://registry.terraform.io/providers/hashicorp/google-beta/latest/docs/resources/google_artifact_registry_repository) | resource |
| [google-beta_google_artifact_registry_repository_iam_binding.repo-admin](https://registry.terraform.io/providers/hashicorp/google-beta/latest/docs/resources/google_artifact_registry_repository_iam_binding) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_description"></a> [description](#input\_description) | Description for the artifact registry | `string` | `""` | no |
| <a name="input_location"></a> [location](#input\_location) | The region where the artifavt registry will be provisioned | `string` | `"europe-west1"` | no |
| <a name="input_project_id"></a> [project\_id](#input\_project\_id) | The project ID containig atlantis resources | `string` | `"moonpay-sre"` | no |
| <a name="input_repo_admin_iam_members"></a> [repo\_admin\_iam\_members](#input\_repo\_admin\_iam\_members) | The members for the repo admin IAM binding | `list(string)` | <pre>[<br>  "serviceAccount:svc-sre@moonpay-sre.iam.gserviceaccount.com"<br>]</pre> | no |
| <a name="input_repository_id"></a> [repository\_id](#input\_repository\_id) | The respository name or ID | `string` | `"npm-moonpay-registry"` | no |
| <a name="input_type"></a> [type](#input\_type) | The artifact regitry type. Values: DOCKER, MAVEN, NPM, PYTHON, APT, YUM, HELM | `string` | `"NPM"` | no |

## Outputs

No outputs.
<!-- END_TF_DOCS -->