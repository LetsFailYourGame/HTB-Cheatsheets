# Google Cloud Platform configuration

This folder contains terraform resources for our Google Cloud Platform environment.

## Structure

Configuration is divided on high level between "organizational" resources and "project" resources.

Organization folder contains resources related to organizational node and folder nodes using following structure:

* `organization/`
    * `folders/`          - Definition of folders in the organization
    * `iam/`              - IAM bindings configuration - split between organizational level and folder level
        * `folders/`      - IAM bindings configured on folder level
        * `organization/` - IAM bindings configured on organizational level
    * `policies/`         - Organizational policies configuration - split between organizational level and folder level
        * `folders/`      - Organizational policies configuration on folder level
        * `organization/` - Organizational policies configuration on organizational level
    * `roles/`            - Definition of custom roles

Project folder contains project related resources configuration in a following structure:
* `projects`
    * `<project_name>`
        * `<project_def>.tf` - Project definition terraform code
        * `resources/`       - Folder containing definitions for project related resources
